import './App.css';
import Home from './Home.js';
import About from './About.js';
import Contact from './Contact.js';

function App() {
  return (
    <div className="App">
      <Home title="Home Page" description="Welcome to our website."/>
      <About title="About Us" description="We are passionate about delivering quality experiences."/>
      <Contact title="Contact Us" description="Feel free to reach out to use via email or phone."/>
    </div>
  );
}

export default App;
