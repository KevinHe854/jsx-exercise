import logo from './logo.svg';
import './App.css';
import EngineeringTopics from './EngineeringTopics'

function App() {
  return (
    <div className="App">
      <h1>ENSF-381: Full Stack Web Development</h1>
      <p>React Components</p>
      <EngineeringTopics />
    </div>
    
  );
}



export default App;
